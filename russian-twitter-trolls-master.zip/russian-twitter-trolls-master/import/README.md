## Data import and Scraping

This directory contains Jupyter notebooks for scraping Tweet data from Internet Archive and importing into Neo4j.

~~~
pip install -r requirements.txt
jupyter notebook
~~~